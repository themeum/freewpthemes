<?php
/*
 * Plugin Name:       WP Mega Menu Pro
 * Plugin URI:        https://www.themeum.com/product/wp-megamenu/
 * Description:       This plugins is a pro version of WP Megamenu regular version
 * Version:           1.2.4
 * Author:            Themeum
 * Author URI:        https://themeum.com
 * Text Domain:       wp-megamenu-pro
 * Domain Path:       /languages
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Language Load
add_action( 'init', 'wpmm_pro_language_load');
function wpmm_pro_language_load(){
    $plugin_dir = basename(dirname(__FILE__))."/languages/";
    load_plugin_textdomain('wp-megamenu-pro', false, $plugin_dir );
}

//Defining WP Megamenu Pro Version
define('WPMM_PRO_VERSION', '1.2.4');

// Define Dir URL
define('WPMM_PRO_DIR_URL', plugin_dir_url(__FILE__));

// Define Physical Path
define('WPMM_PRO_DIR_PATH', plugin_dir_path(__FILE__));

//WP Megamenu Base Name
define('WPMM_PRO_BASENAME', plugin_basename(__FILE__));

function wpmm_admin_notice() { 
    ?>
        <div class="notice error">
            <p><?php _e('You must be installed WP Megamenu plugin to use WP Megamenu Pro features! <a href="https://wordpress.org/plugins/wp-megamenu/" target="_blank">Download WP Megamenu</a>', 'wp-megamenu-pro' ); ?></p>
        </div>
    <?php
}

// wpmm installed
include_once(ABSPATH . 'wp-admin/includes/plugin.php');
if (!is_plugin_active('wp-megamenu/wp-megamenu.php')) {
    add_action('admin_notices', 'wpmm_admin_notice');
    return;
}

require WPMM_PRO_DIR_PATH . 'classes/WPMM_Pro.php';