<?php
/**
 * Addon: WP Megamenu Feature Box Pro
 */

class WP_Mega_Menu_Feature_Box_Pro extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wp_mgeamenu_featurebox_pro', // Base ID
			esc_html__( 'WPMM Feature Box Pro', 'wp-megamenu' ), // Name
			array( 'description' => esc_html__( 'Features Box Pro widget to display in WP Mega Menu', 'wp-megamenu' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {

		if ( ! empty($instance['box_layout']) ) {
			$layout     = $instance['box_layout'];
		} else {
			$layout     = 'layout_1';
		}

		if ( ! empty($instance['box_align']) ) {
			$box_align  = $instance['box_align'];
		} else {
			$box_align  = 'wpmmtextleft';
		}
		$featuretitle 	= ! empty($instance['feature_title'])? $instance['feature_title'] : '';
		$featureicon 	= ! empty($instance['feature_icon']) ? $instance['feature_icon'] : '';
		$featuredesc 	= ! empty($instance['feature_desc']) ? $instance['feature_desc']: '';
		$feature_img_url 	= ! empty($instance['feature_img_url']) ? $instance['feature_img_url']: '';
		$featurebtntext 	= ! empty($instance['feature_btn_text']) ? $instance['feature_btn_text'] : '';
		$featurebtnurl  = ! empty($instance['feature_btn_url']) ? $instance['feature_btn_url'] : '';
		$featureiconsize    = ! empty($instance['feature_icon_size']) ? $instance['feature_icon_size'] : '';
		$featuretitlesize   = ! empty($instance['feature_title_size']) ? $instance['feature_title_size'] : '';
		$featuretitlemargin   = ! empty($instance['feature_title_margin']) ? $instance['feature_title_margin'] : '';
		$titleweight   = ! empty($instance['title_weight']) ? $instance['title_weight'] : '';
		$featuredescsize 	= ! empty($instance['feature_desc_size']) ? $instance['feature_desc_size'] : '';
		$title_text_transform = ! empty($instance['title_text_transform']) ? $instance['title_text_transform'] : '';

		if ( ! empty($instance['btn_size']) ) {
			$btn_size 	= $instance['btn_size'];
		} else {
			$btn_size 	= 'wpmmbtnsize_m';
		}
		$featureiconcolor   =  ! empty($instance['feature_icon_color']) ? $instance['feature_icon_color'] : '';
		$featuretitlecolor  = ! empty($instance['feature_title_color']) ? $instance['feature_title_color'] : '';
		$featuredesccolor   = ! empty($instance['feature_desc_color']) ? $instance['feature_desc_color'] : '';
		$featurebtncolor    = ! empty($instance['feature_btn_color']) ? $instance['feature_btn_color'] : '';
		$featurebtnbgcolor  = ! empty($instance['feature_btn_bg_color']) ? $instance['feature_btn_bg_color'] : '';
		$featurebtnhcolor   = ! empty($instance['feature_btn_h_color']) ? $instance['feature_btn_h_color'] : '';
		$featurebtnhbgcolor = ! empty($instance['feature_btn_h_bg_color']) ? $instance['feature_btn_h_bg_color'] : '';

		$wrapper_bg_color       = ! empty($instance['wrapper_bg_color']) ? $instance['wrapper_bg_color'] : '';
		$wrapper_padding        = ! empty($instance['wrapper_padding']) ? $instance['wrapper_padding'] : '';
		$wrapper_border_radius  = ! empty($instance['wrapper_border_radius']) ? $instance['wrapper_border_radius'] : '';
		$boxshadow_enable       = ! empty($instance['boxshadow_enable']) ? $instance['boxshadow_enable'] : '';
		$boxshadow_dimension    = ! empty($instance['boxshadow_dimension']) ? $instance['boxshadow_dimension'] : '';
		$boxshadow_color        = ! empty($instance['boxshadow_color']) ? $instance['boxshadow_color'] : '';

		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}

		$output = $iconstyle = $titlestyle = $descstyle = $btnstyle = '';

		//icon style
		if( $featureiconsize ) { $iconstyle .= 'font-size:'. (int)esc_attr( $featureiconsize ) .'px;';}
		if( $featureiconcolor ) { $iconstyle .= 'color:'. esc_attr( $featureiconcolor ) .';';}
		if( $featureiconsize || $featureiconcolor ) {
			$iconstyle = 'style="'.$iconstyle.'"';
		}

		//title style
		if( $title_text_transform ) { $titlestyle .= 'text-transform: '.$title_text_transform.';';}
		if( $featuretitlesize ) { $titlestyle .= 'font-size:'. (int)esc_attr( $featuretitlesize ) .'px;';}
		if( $titleweight ) { $titlestyle .= 'font-weight:'. esc_attr( $titleweight ) .';';}
		if( $featuretitlemargin ) { $titlestyle .= 'margin:'. esc_attr( $featuretitlemargin ) .';';}
		if( $featuretitlecolor ) { $titlestyle .= 'color:'. esc_attr( $featuretitlecolor ) .';';}
		if( $featuretitlesize || $featuretitlecolor ) {
			$titlestyle = 'style="'.$titlestyle.'"';
		}

		//Desc style
		if( $featuredescsize ) { $descstyle .= 'font-size:'. (int)esc_attr( $featuredescsize ) .'px;';}
		if( $featuredesccolor ) { $descstyle .= 'color:'. esc_attr( $featuredesccolor ) .';';}
		if( $featuredescsize || $featuredesccolor ) {
			$descstyle = 'style="'.$descstyle.'"';
		}

		//button style
		if( $featurebtnbgcolor ) { $btnstyle .= 'background:'. esc_attr( $featurebtnbgcolor ) .';';}
		if( $featurebtncolor ) { $btnstyle .= 'color:'. esc_attr( $featurebtncolor ) .';';}
		if( $featurebtnbgcolor || $featurebtncolor ) {
			$btnstyle = 'style="'.$btnstyle.'"';
		}


		$feature_box_style = ' style="';
		if ( ! empty($wrapper_bg_color)){
			$feature_box_style .= "background-color: {$wrapper_bg_color}; ";
		}
		if ($boxshadow_enable === 'enable'){
			$feature_box_style .= "-webkit-box-shadow: {$boxshadow_dimension} {$boxshadow_color}; ";
			$feature_box_style .= "-moz-box-shadow: {$boxshadow_dimension} {$boxshadow_color}; ";
			$feature_box_style .= "box-shadow: {$boxshadow_dimension} {$boxshadow_color}; ";
		}
		if ( ! empty($wrapper_padding)){
			$feature_box_style .= "padding: {$wrapper_padding}; ";
		}
		if ( ! empty($wrapper_border_radius)){
			$feature_box_style .= "border-radius: {$wrapper_border_radius}; ";
		}

		$feature_box_style .= ' " ';



		$output .='<div class="wpmm-feature-box-pro" '.$feature_box_style.' >';

		$feature_image = '';;
		if ( ! empty($feature_img_url)){
			$feature_image ='<img src="'.$feature_img_url.'" />';
		}

		switch ( $layout ) {
			case 'layout_1':
				$output .='<div class="wpmm-feature-item '.$layout.' '.$box_align.'">';
				$output .='<div class="wpmm-feature-item">';
				if ( isset($featureicon) && !empty($featureicon) ) {
					$output .='<i class="fa '.$featureicon.'" '.$iconstyle.'></i>';
				}
				$output .= $feature_image;
				if (isset($featuretitle)) {
					$output .='<h4 class="wpmm-feature-title" '.$titlestyle.'>'.$featuretitle.'</h4>';
				}
				if (isset($featuredesc)) {
					$output .='<div class="wpmm-feature-desc" '.$descstyle.'>'.$featuredesc.'</div>';
				}
				if (isset($featurebtnurl) && !empty($featurebtnurl) ) {
					$output     .= '<a data-hover-color="'.esc_attr($featurebtnhcolor).'" data-hover-bg-color="'.esc_attr($featurebtnhbgcolor).'" class="wpmm-featurebox-hcolor wpmm-featurebox-btn '.$btn_size .'" href="'.$featurebtnurl.'" '.$btnstyle.'>' . $featurebtntext . '</a>';
				}
				$output .='</div>';
				$output .='</div>';
				break;

			case 'layout_2':


				$output .='<div class="wpmm-feature-item '.$layout.' '.$box_align.'">';
				$output .='<div class="wpmm-feature-item">';
				if ( isset($featureicon) && !empty($featureicon) ) {
					$output .='<i class="fa '.$featureicon.'" '.$iconstyle.'></i>';
				}

				if (isset($featuretitle)) {
					$output .='<h4 class="wpmm-feature-title" '.$titlestyle.'>'.$featuretitle.'</h4>';
				}
				$output .= $feature_image;
				if (isset($featuredesc)) {
					$output .='<div class="wpmm-feature-desc" '.$descstyle.'>'.$featuredesc.'</div>';
				}
				if (isset($featurebtnurl) && !empty($featurebtnurl) ) {
					$output     .= '<a data-hover-color="'.esc_attr($featurebtnhcolor).'" data-hover-bg-color="'.esc_attr($featurebtnhbgcolor).'" class="wpmm-featurebox-hcolor wpmm-featurebox-btn '.$btn_size .'" href="'.$featurebtnurl.'" '.$btnstyle.'>' . $featurebtntext . '</a>';
				}
				$output .='</div>';
				$output .='</div>';


				break;

			case  'layout_3':

				$output .='<div class="wpmm-feature-item '.$layout.' '.$box_align.'">';
				$output .='<div class="wpmm-feature-item">';
				if ( isset($featureicon) && !empty($featureicon) ) {
					$output .='<i class="fa '.$featureicon.'" '.$iconstyle.'></i>';
				}
				if (isset($featuretitle)) {
					$output .='<h4 class="wpmm-feature-title" '.$titlestyle.'>'.$featuretitle.'</h4>';
				}
				if (isset($featuredesc)) {
					$output .='<div class="wpmm-feature-desc" '.$descstyle.'>'.$featuredesc.'</div>';
				}
				$output .= $feature_image;
				if (isset($featurebtnurl) && !empty($featurebtnurl) ) {
					$output     .= '<a data-hover-color="'.esc_attr($featurebtnhcolor).'" data-hover-bg-color="'.esc_attr($featurebtnhbgcolor).'" class="wpmm-featurebox-hcolor wpmm-featurebox-btn '.$btn_size .'" href="'.$featurebtnurl.'" '.$btnstyle.'>' . $featurebtntext . '</a>';
				}
				$output .='</div>';
				$output .='</div>';

				break;

			case 'layout_4':

				$output .='<div class="wpmm-feature-item '.$layout.' '.$box_align.'">';
				$output .='<div class="wpmm-feature-item-with-media">';

				$output .= '<div class="wpmm-featurebox-pro-media">';
				$output .= $feature_image;
				$output .= '</div>';

				$output .= '<div class="wpmm-featurebox-pro-body">';

				if ( isset($featureicon) && !empty($featureicon) ) {
					$output .='<i class="fa '.$featureicon.'" '.$iconstyle.'></i>';
				}
				if (isset($featuretitle)) {
					$output .='<h4 class="wpmm-feature-title" '.$titlestyle.'>'.$featuretitle.'</h4>';
				}
				if (isset($featuredesc)) {
					$output .='<div class="wpmm-feature-desc" '.$descstyle.'>'.$featuredesc.'</div>';
				}
				if (isset($featurebtnurl) && !empty($featurebtnurl) ) {
					$output     .= '<a data-hover-color="'.esc_attr($featurebtnhcolor).'" data-hover-bg-color="'.esc_attr($featurebtnhbgcolor).'" class="wpmm-featurebox-hcolor wpmm-featurebox-btn '.$btn_size .'" href="'.$featurebtnurl.'" '.$btnstyle.'>' . $featurebtntext . '</a>';
				}

				$output .= '</div>';

				$output .='</div>';
				$output .='</div>';

				break;

			case 'layout_5':

				$output .='<div class="wpmm-feature-item '.$layout.' '.$box_align.'">';
				$output .='<div class="wpmm-feature-item-with-media">';

				$output .= '<div class="wpmm-featurebox-pro-body">';
				if ( isset($featureicon) && !empty($featureicon) ) {
					$output .='<i class="fa '.$featureicon.'" '.$iconstyle.'></i>';
				}
				if (isset($featuretitle)) {
					$output .='<h4 class="wpmm-feature-title" '.$titlestyle.'>'.$featuretitle.'</h4>';
				}
				if (isset($featuredesc)) {
					$output .='<div class="wpmm-feature-desc" '.$descstyle.'>'.$featuredesc.'</div>';
				}
				if (isset($featurebtnurl) && !empty($featurebtnurl) ) {
					$output     .= '<a data-hover-color="'.esc_attr($featurebtnhcolor).'" data-hover-bg-color="'.esc_attr($featurebtnhbgcolor).'" class="wpmm-featurebox-hcolor wpmm-featurebox-btn '.$btn_size .'" href="'.$featurebtnurl.'" '.$btnstyle.'>' . $featurebtntext . '</a>';
				}

				$output .= '</div>';

				$output .= '<div class="wpmm-featurebox-pro-media">';
				$output .= $feature_image;
				$output .= '</div>';

				$output .='</div>';
				$output .='</div>';
				break;
			default:

				break;
		}
		$output .='</div>';

		echo $output;
		echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$defaults = array(
			'title' 					=> 'New Title',
			'box_align'                 => 'wpmmtextleft',
			'box_layout' 				=> 'layout_1',
			'feature_icon' 				=> '',
			'feature_title' 			=> '',
			'feature_desc' 				=> '',
			'feature_img_url' 		    => '',
			'feature_btn_url' 			=> '',
			'feature_btn_text'          => '',
			'feature_icon_size'         => '40',
			'feature_title_margin'      => '14px 0px 6px 0px',
			'feature_title_size'        => '15',
			'title_weight'              => '600',
			'feature_desc_size'         => '13',
			'btn_size' 			        => 'wpmmbtnsize_m',
			'feature_icon_color' 		=> '',

			'wrapper_bg_color' 		    => '',
			'wrapper_padding' 		    => '',
			'wrapper_border_radius'     => '',
			'boxshadow_enable' 		    => '',
			'boxshadow_dimension' 		=> '',
			'boxshadow_color' 		    => '',

			'feature_title_color' 		=> '',
			'feature_desc_color' 		=> '',
			'feature_btn_color' 		=> '',
			'feature_btn_bg_color' 		=> '',
			'feature_btn_h_color' 		=> '',
			'feature_btn_h_bg_color' 	=> ''
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'wp-megamenu' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'box_layout' ); ?>"><?php esc_html_e('Select Layout', 'wp-megamenu'); ?></label>
			<?php
			$options = array(
				'layout_1' 	=> 'Layout 1',
				'layout_2' 	=> 'Layout 2',
				'layout_3' 	=> 'Layout 3',
				'layout_4' 	=> 'Layout 4',
				'layout_5' 	=> 'Layout 5',
			);
			if(isset($instance['box_layout'])) $box_layout = $instance['box_layout'];
			?>
            <select class="widefat" id="<?php echo $this->get_field_id( 'box_layout' ); ?>" name="<?php echo $this->get_field_name( 'box_layout' ); ?>">
				<?php
				$op = '<option value="%s"%s>%s</option>';

				foreach ($options as $key=>$value ) {

					if ($box_layout === $key) {
						printf($op, $key, ' selected="selected"', $value);
					} else {
						printf($op, $key, '', $value);
					}
				}
				?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'box_align' ); ?>"><?php esc_html_e('Alignment', 'wp-megamenu'); ?></label>
			<?php
			$options = array(
				'wpmmtextleft' 		=> 'Left',
				'wpmmtextcenter' 	=> 'Center',
				'wpmmtextright'		=> 'Right',
			);
			if(isset($instance['box_align'])) $box_align = $instance['box_align'];
			?>
            <select class="widefat" id="<?php echo $this->get_field_id( 'box_align' ); ?>" name="<?php echo $this->get_field_name( 'box_align' ); ?>">
				<?php
				$op = '<option value="%s"%s>%s</option>';

				foreach ($options as $key=>$value ) {
					if ($box_align === $key) {
						printf($op, $key, ' selected="selected"', $value);
					} else {
						printf($op, $key, '', $value);
					}
				}
				?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_icon' ); ?>"><?php esc_html_e('Select Icon', 'wp-megamenu'); ?></label>
            <select id="<?php echo $this->get_field_id( 'feature_icon' ); ?>" class="wpmm-select2" name="<?php echo $this->get_field_name( 'feature_icon' ); ?>" >
				<?php
				$font_awesome = wpmm_font_awesome();
				echo '<option value=""> '.__('None', 'wp-megamenu').' </option>';
				foreach ($font_awesome as $icon_key => $icon_value){
					echo '<option '.selected( $instance['feature_icon'], $icon_value).' value="'.$icon_value.'" selec data-icon="'.$icon_value.'">'.str_replace('fa-', '', $icon_value).'</option>';
				}
				?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_title' ); ?>"><?php esc_html_e('Feature Title', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'feature_title' ); ?>" name="<?php echo $this->get_field_name( 'feature_title' ); ?>" value="<?php echo $instance['feature_title']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_desc' ); ?>"><?php esc_html_e('Feature Description', 'wp-megamenu'); ?></label>
            <textarea id="<?php echo $this->get_field_id( 'feature_desc' ); ?>" rows="5" name="<?php echo $this->get_field_name( 'feature_desc' ); ?>" style="width:100%;"><?php echo $instance['feature_desc']; ?></textarea>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'feature_img_url' ); ?>"><?php esc_html_e('Feature Image', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat feature_img_url" id="<?php echo $this->get_field_id( 'feature_img_url' ); ?>" name="<?php echo $this->get_field_name( 'feature_img_url' ); ?>" value="<?php echo $instance['feature_img_url']; ?>" style="width:100%;" />
            <br /><br />
            <input type="button" class="wpmm_featurebox_pro_image_btn button button-primary" value="<?php _e('Upload Image', 'wp-megamenu'); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'feature_btn_text' ); ?>"><?php esc_html_e('Button Text', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'feature_btn_text' ); ?>" name="<?php echo $this->get_field_name( 'feature_btn_text' ); ?>" value="<?php echo $instance['feature_btn_text']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_btn_url' ); ?>"><?php esc_html_e('Button Link', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'feature_btn_url' ); ?>" name="<?php echo $this->get_field_name( 'feature_btn_url' ); ?>" value="<?php echo $instance['feature_btn_url']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_style' ); ?>"><?php esc_html_e('Feature Style', 'wp-megamenu'); ?></label></p>
        <hr/>

        <p>
            <label for="<?php echo $this->get_field_id( 'title_text_transform' ); ?>"><?php esc_html_e('Title Text Transform', 'wp-megamenu'); ?></label>
			<?php
			$options = array(
				'uppercase'   => 'UPPERCASE',
				'lowercase'   => 'lowercase',
				'capitalize'   => 'Capitalize',
			);
			$title_text_transform = '';
			if(! empty($instance['title_text_transform'])){
				$title_text_transform = $instance['title_text_transform'];
			}
			?>
            <select class="widefat" id="<?php echo $this->get_field_id( 'title_text_transform' ); ?>" name="<?php echo
			$this->get_field_name( 'title_text_transform' ); ?>">
				<?php
				$op = '<option value="%s"%s>%s</option>';
				foreach ($options as $key => $value ) {
					if ($title_text_transform === $key) {
						printf($op, $key, ' selected="selected"', $value);
					} else {
						printf($op, $key, '', $value);
					}
				}
				?>
            </select>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'btn_size' ); ?>"><?php esc_html_e('Button Size', 'wp-megamenu'); ?></label>
			<?php
			$options = array(
				'wpmmbtnsize_s'   => 'Small',
				'wpmmbtnsize_m'   => 'Medium',
				'wpmmbtnsize_l'   => 'Large',
			);
			if(isset($instance['btn_size'])) $btn_size = $instance['btn_size'];
			?>
            <select class="widefat" id="<?php echo $this->get_field_id( 'btn_size' ); ?>" name="<?php echo $this->get_field_name( 'btn_size' ); ?>">
				<?php
				$op = '<option value="%s"%s>%s</option>';

				foreach ($options as $key=>$value ) {

					if ($btn_size === $key) {
						printf($op, $key, ' selected="selected"', $value);
					} else {
						printf($op, $key, '', $value);
					}
				}
				?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_icon_size' ); ?>"><?php esc_html_e('Iocn Font Size Ex. 20px', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'feature_icon_size' ); ?>" name="<?php echo $this->get_field_name( 'feature_icon_size' ); ?>" value="<?php echo $instance['feature_icon_size']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_title_size' ); ?>"><?php esc_html_e('Title Font Size Ex. 18px', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'feature_title_size' ); ?>" name="<?php echo $this->get_field_name( 'feature_title_size' ); ?>" value="<?php echo $instance['feature_title_size']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_title_margin' ); ?>"><?php esc_html_e('Title Margin Ex. 10px 10px 10px 10px', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'feature_title_margin' ); ?>" name="<?php echo $this->get_field_name( 'feature_title_margin' ); ?>" value="<?php echo $instance['feature_title_margin']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'title_weight' ); ?>"><?php esc_html_e('Title font weight', 'wp-megamenu'); ?></label>
			<?php
			$weightoptions = array(
				'300'   => '300',
				'400'   => '400',
				'500'   => '500',
				'600'   => '600',
				'700'   => '700',
				'800'   => '800',
			);
			if(isset($instance['title_weight'])) $title_weight = $instance['title_weight'];
			?>
            <select class="widefat" id="<?php echo $this->get_field_id( 'title_weight' ); ?>" name="<?php echo $this->get_field_name( 'title_weight' ); ?>">
				<?php
				$weightop = '<option value="%s"%s>%s</option>';

				foreach ($weightoptions as $weightkey=>$fontvalue ) {
					if ($title_weight === $weightkey) {
						printf($weightop, $weightkey, ' selected="selected"', $fontvalue);
					} else {
						printf($weightop, $weightkey, '', $fontvalue);
					}
				}
				?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_desc_size' ); ?>"><?php esc_html_e('Description Font Size Ex. 14px', 'wp-megamenu'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'feature_desc_size' ); ?>" name="<?php echo $this->get_field_name( 'feature_desc_size' ); ?>" value="<?php echo $instance['feature_desc_size']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'wrapper_bg_color' ); ?>"> <?php _e('Wrapper BG Color', 'wp-megamenu'); ?>  </label>
            <input type="text" class="widefat wpmmColorPicker" data-alpha="true" id="<?php echo $this->get_field_id( 'wrapper_bg_color' ); ?>"
                   name="<?php echo $this->get_field_name( 'wrapper_bg_color' ); ?>" value="<?php echo $instance['wrapper_bg_color']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'wrapper_padding' ); ?>"> <?php _e('Padding, Ex.', 'wp-megamenu'); ?> <code>10px 10px 10px 10px</code> </label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'wrapper_padding' ); ?>" name="<?php echo $this->get_field_name( 'wrapper_padding' ); ?>" value="<?php echo $instance['wrapper_padding']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'wrapper_border_radius' ); ?>"> <?php _e('Border Radius, Ex:', 'wp-megamenu'); ?> <code>10px</code></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'wrapper_border_radius' ); ?>" name="<?php echo $this->get_field_name( 'wrapper_border_radius' ); ?>" value="<?php echo $instance['wrapper_border_radius']; ?>" style="width:100%;" />
        </p>


        <div class="featurebox-pro-input-group">
            <p class="featurebox-pro-input-group-title"><?php _e('Box Shadow', 'wp-megamenu') ?></p>

            <p>
                <label for="<?php echo $this->get_field_id( 'boxshadow_enable' ); ?>">
                    <?php _e('Enable', 'wp-megamenu'); ?>
                </label>
                <label>
                    <input type="radio" name="<?php echo $this->get_field_name( 'boxshadow_enable' ); ?>" value="enable" <?php checked($instance['boxshadow_enable'], 'enable'); ?>  /> <?php _e('Enable', 'wp-megamenu'); ?>
                </label>
                <label>
                    <input type="radio" name="<?php echo $this->get_field_name( 'boxshadow_enable' ); ?>" value="disable" <?php checked($instance['boxshadow_enable'], 'disable'); ?>  /> <?php _e('Disable', 'wp-megamenu'); ?>
                </label>
            </p>


            <p>
                <label for="<?php echo $this->get_field_id( 'boxshadow_dimension' ); ?>"> <?php _e('Dimension', 'wp-megamenu'); ?> <code>10px 10px 10px 10px</code> </label>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'boxshadow_dimension' ); ?>" name="<?php echo $this->get_field_name( 'boxshadow_dimension' ); ?>" value="<?php echo $instance['boxshadow_dimension']; ?>" style="width:100%;" />
            </p>

            <p>
                <label for="<?php echo $this->get_field_id( 'boxshadow_color' ); ?>"><?php esc_html_e('Icon Color', 'wp-megamenu'); ?></label>
                <input type="text" id="<?php echo $this->get_field_id( 'boxshadow_color' ); ?>"  name="<?php echo
		        $this->get_field_name( 'boxshadow_color' ); ?>" value="<?php echo $instance['boxshadow_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
            </p>

        </div>


        <p>
            <label for="<?php echo $this->get_field_id( 'feature_icon_color' ); ?>"><?php esc_html_e('Icon Color', 'wp-megamenu'); ?></label>
            <input type="text" id="<?php echo $this->get_field_id( 'feature_icon_color' ); ?>"  name="<?php echo
			$this->get_field_name( 'feature_icon_color' ); ?>" value="<?php echo $instance['feature_icon_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_title_color' ); ?>"><?php esc_html_e('Title Color', 'wp-megamenu'); ?></label>
            <input type="text" id="<?php echo $this->get_field_id( 'feature_title_color' ); ?>" name="<?php echo $this->get_field_name( 'feature_title_color' ); ?>" value="<?php echo $instance['feature_title_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_desc_color' ); ?>"><?php esc_html_e('Description Color', 'wp-megamenu'); ?></label>
            <input type="text" id="<?php echo $this->get_field_id( 'feature_desc_color' ); ?>" name="<?php echo $this->get_field_name( 'feature_desc_color' ); ?>" value="<?php echo $instance['feature_desc_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_btn_color' ); ?>"><?php esc_html_e('Button Color', 'wp-megamenu'); ?></label>
            <input type="text" id="<?php echo $this->get_field_id( 'feature_btn_color' ); ?>" name="<?php echo $this->get_field_name( 'feature_btn_color' ); ?>" value="<?php echo $instance['feature_btn_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_btn_bg_color' ); ?>"><?php esc_html_e('Button Background Color', 'wp-megamenu'); ?></label>
            <input type="text" id="<?php echo $this->get_field_id( 'feature_btn_bg_color' ); ?>" name="<?php echo $this->get_field_name( 'feature_btn_bg_color' ); ?>" value="<?php echo $instance['feature_btn_bg_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_btn_h_color' ); ?>"><?php esc_html_e('Button Hover Color', 'wp-megamenu'); ?></label>
            <input type="text" id="<?php echo $this->get_field_id( 'feature_btn_h_color' ); ?>" name="<?php echo $this->get_field_name( 'feature_btn_h_color' ); ?>" value="<?php echo $instance['feature_btn_h_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'feature_btn_h_bg_color' ); ?>"><?php esc_html_e('Button Hover Background Color', 'wp-megamenu'); ?></label>
            <input type="text" id="<?php echo $this->get_field_id( 'feature_btn_h_bg_color' ); ?>" name="<?php echo $this->get_field_name( 'feature_btn_h_bg_color' ); ?>" value="<?php echo $instance['feature_btn_h_bg_color']; ?>" style="width:100%;"  class="wpmmColorPicker" data-alpha="true" />
        </p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$n = $new_instance;

		$instance['title']                  = ( ! empty( $n['title'] ) ) ? sanitize_text_field( $n['title'] ) : '';
		$instance['box_align']              = ( ! empty( $n['box_align'] ) ) ? sanitize_text_field( $n['box_align'] ) : '';
		$instance['box_layout']             = ( ! empty( $n['box_layout'] ) ) ? sanitize_text_field( $n['box_layout'] ) : '';
		$instance['feature_icon_size']      = ( ! empty( $n['feature_icon_size'] ) ) ? sanitize_text_field( $n['feature_icon_size'] ) : '';
		$instance['feature_title_size']     = ( ! empty( $n['feature_title_size'] ) ) ? sanitize_text_field( $n['feature_title_size'] ) : '';
		$instance['feature_title_margin']   = ( ! empty( $n['feature_title_margin'] ) ) ? sanitize_text_field( $n['feature_title_margin'] ) : '';
		$instance['title_weight']           = ( ! empty( $n['title_weight'] ) ) ? sanitize_text_field( $n['title_weight'] ) : '';
		$instance['feature_desc_size']      = ( ! empty( $n['feature_desc_size'] ) ) ? sanitize_text_field( $n['feature_desc_size'] ) : '';
		$instance['feature_icon']           = ( ! empty( $n['feature_icon'] ) ) ? sanitize_text_field( $n['feature_icon'] ) : '';
		$instance['feature_title']          = ( ! empty( $n['feature_title'] ) ) ? sanitize_text_field( $n['feature_title'] ) : '';
		$instance['feature_desc']           = ( ! empty( $n['feature_desc'] ) ) ? sanitize_text_field( $n['feature_desc'] ) : '';
		$instance['feature_img_url']           = ( ! empty( $n['feature_img_url'] ) ) ? sanitize_text_field( $n['feature_img_url'] ) : '';
		$instance['feature_btn_url']        = ( ! empty( $n['feature_btn_url'] ) ) ? sanitize_text_field( $n['feature_btn_url'] ) : '';

		$instance['feature_btn_text']       = ( ! empty( $n['feature_btn_text'] ) ) ? sanitize_text_field( $n['feature_btn_text'] ) : '';
		$instance['title_text_transform']   = ( ! empty( $n['title_text_transform'] ) ) ? sanitize_text_field( $n['title_text_transform'] ) : '';
		$instance['btn_size']               = ( ! empty( $n['btn_size'] ) ) ? sanitize_text_field( $n['btn_size'] ) : '';
		$instance['feature_icon_color']     = ( ! empty( $n['feature_icon_color'] ) ) ? sanitize_text_field( $n['feature_icon_color'] ) : '';

		$instance['boxshadow_color']     = ( ! empty( $n['boxshadow_color'] ) ) ? sanitize_text_field( $n['boxshadow_color'] ) : '';
		$instance['boxshadow_dimension']     = ( ! empty( $n['boxshadow_dimension'] ) ) ? sanitize_text_field( $n['boxshadow_dimension'] ) : '';
		$instance['boxshadow_enable']     = ( ! empty( $n['boxshadow_enable'] ) ) ? sanitize_text_field( $n['boxshadow_enable'] ) : '';
		$instance['wrapper_border_radius']     = ( ! empty( $n['wrapper_border_radius'] ) ) ? sanitize_text_field( $n['wrapper_border_radius'] ) : '';
		$instance['wrapper_padding']     = ( ! empty( $n['wrapper_padding'] ) ) ? sanitize_text_field( $n['wrapper_padding'] ) : '';
		$instance['wrapper_bg_color']     = ( ! empty( $n['wrapper_bg_color'] ) ) ? sanitize_text_field( $n['wrapper_bg_color'] ) : '';

		$instance['feature_title_color']    = ( ! empty( $n['feature_title_color'] ) ) ? sanitize_text_field( $n['feature_title_color'] ) : '';
		$instance['feature_desc_color']     = ( ! empty( $n['feature_desc_color'] ) ) ? sanitize_text_field( $n['feature_desc_color'] ) : '';
		$instance['feature_btn_color']      = ( ! empty( $n['feature_btn_color'] ) ) ? sanitize_text_field( $n['feature_btn_color'] ) : '';
		$instance['feature_btn_bg_color']   = ( ! empty( $n['feature_btn_bg_color'] ) ) ? sanitize_text_field( $n['feature_btn_bg_color'] ) : '';
		$instance['feature_btn_h_color']    = ( ! empty( $n['feature_btn_h_color'] ) ) ? sanitize_text_field( $n['feature_btn_h_color'] ) : '';
		$instance['feature_btn_h_bg_color'] = ( ! empty( $n['feature_btn_h_bg_color'] ) ) ? sanitize_text_field( $n['feature_btn_h_bg_color'] ) : '';

		return $instance;
	}
}

// register Foo_Widget widget
function register_wp_megamenu_featurebox_pro() {
	register_widget( 'WP_Mega_Menu_Feature_Box_Pro' );
}
add_action( 'widgets_init', 'register_wp_megamenu_featurebox_pro' );



/*-----------------------------------------------------
 * 				script load
*----------------------------------------------------*/
function wpmm_featuresbox_pro_scripts() {
	wp_enqueue_style( 
		'wpmm-feature-box-pro-css', 
		WPMM_PRO_DIR_URL .'addons/wpmm-featuresbox-pro/wpmm-featuresbox-pro.css',
		array(), 
		WPMM_PRO_VERSION 
	);
	wp_enqueue_script( 
		'wpmm-featurebox-pro-script', 
		WPMM_PRO_DIR_URL .'addons/wpmm-featuresbox-pro/featuresbox-pro.js', 
		array('jquery'), 
		WPMM_PRO_VERSION, 
		true 
	);
}
add_action( 'wp_enqueue_scripts', 'wpmm_featuresbox_pro_scripts' );
add_action( 'admin_enqueue_scripts', 'wpmm_featuresbox_pro_scripts' );