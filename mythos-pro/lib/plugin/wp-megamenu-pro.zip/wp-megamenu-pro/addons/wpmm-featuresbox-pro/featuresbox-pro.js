jQuery(document).ready(function($){'use strict';

	var clr = '';
	var clr_bg = '';
	$(".wpmm-featurebox-hcolor").on({
	    mouseenter: function () {
	     	clr = $(this).css('color');
			clr_bg = $(this).css('backgroundColor');
			$(this).css("color", $(this).data("hover-color"));
			$(this).css("background-color", $(this).data("hover-bg-color"));
	    },
	    mouseleave: function () {
	        $(this).css("color", clr );
			$(this).css("background-color", clr_bg );
	    }
	});

	$(document).on('click', '.wpmm_featurebox_pro_image_btn', function(e){
		e.preventDefault();

        // Set all variables to be used in scope
        var frame;
        // If the media frame already exists, reopen it.
        if ( frame ) {
            frame.open();
            return;
        }
		frame = wp.media({
            title: 'Select or upload media of your chosen persuasion',
            button: {
                text: 'Use this media'
            },
            multiple: false  // Set to true to allow multiple files to be selected
        });
        frame.on( 'select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
			$('.feature_img_url').val(attachment.url).change();
        });
		frame.open();
    });

});