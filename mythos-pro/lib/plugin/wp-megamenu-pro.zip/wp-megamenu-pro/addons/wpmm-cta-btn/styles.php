<?php


add_filter('wpmm_generated_css', 'wpmm_pro_cta_btn_style', 10, 3);

function wpmm_pro_cta_btn_style($style, $navbar_id, $theme) {

    $cta_btn_color = !empty($theme['cta_btn_color']) ? $theme['cta_btn_color'] : '#ffffff';
    $cta_btn_hover_color = !empty($theme['cta_btn_hover_color']) ? $theme['cta_btn_hover_color'] : '#ffffff';
    $cta_btn_font = !empty($theme['cta_btn_font']) ? $theme['cta_btn_font'] : 'inherit';
    $cta_btn_font_size = !empty($theme['cta_btn_font_size']) ? wpmm_unit_to_int($theme['cta_btn_font_size']).'px' : 'inherit';
    $cta_btn_font_weight = !empty($theme['cta_btn_font_weight']) ? $theme['cta_btn_font_weight'] : 'inherit';
    $cta_btn_line_height = !empty($theme['cta_btn_line_height']) ? wpmm_unit_to_int($theme['cta_btn_line_height']).'px' : 'inherit';
    $cta_btn_text_transform = !empty($theme['cta_btn_text_transform']) ? wpmm_unit_to_int($theme['cta_btn_text_transform']).'px' : 'inherit';
    $cta_btn_letter_spacing = !empty($theme['cta_btn_letter_spacing']) ? wpmm_unit_to_int($theme['cta_btn_letter_spacing']).'px' : 'inherit';
    $cta_btn_top_border_width = !empty($theme['cta_btn_top_border_width']) ? wpmm_unit_to_int($theme['cta_btn_top_border_width']).'px' : '0';
    $cta_btn_right_border_width = !empty($theme['cta_btn_right_border_width']) ? wpmm_unit_to_int($theme['cta_btn_right_border_width']).'px' : '0';
    $cta_btn_bottom_border_width = !empty($theme['cta_btn_bottom_border_width']) ? wpmm_unit_to_int($theme['cta_btn_bottom_border_width']).'px' : '0';
    $cta_btn_left_border_width = !empty($theme['cta_btn_left_border_width']) ? wpmm_unit_to_int($theme['cta_btn_left_border_width']).'px' : '0';
    $cta_btn_border_color = !empty($theme['cta_btn_border_color']) ? $theme['cta_btn_border_color'] : '';
    $cta_btn_border_hover_color = !empty($theme['cta_btn_border_hover_color']) ? $theme['cta_btn_border_hover_color'] : '';
    $cta_btn_border_type = !empty($theme['$cta_btn_border_type']) ? $theme['$cta_btn_border_type'] : '';

    $cta_btn_border_radius_top_left = !empty($theme['cta_btn_border_radius_top_left']) ? wpmm_unit_to_int($theme['cta_btn_border_radius_top_left']).'px' : '4px';
    $cta_btn_radius_top_right = !empty($theme['cta_btn_radius_top_right']) ? wpmm_unit_to_int($theme['cta_btn_radius_top_right']).'px' : '4px';
    $cta_radius_bottom_left = !empty($theme['cta_radius_bottom_left']) ? wpmm_unit_to_int($theme['cta_radius_bottom_left']).'px' : '4px';
    $cta_radius_bottom_right = !empty($theme['cta_radius_bottom_right']) ? wpmm_unit_to_int($theme['cta_radius_bottom_right']).'px' : '4px';

    $cta_padding_top = !empty($theme['cta_padding_top']) ? wpmm_unit_to_int($theme['cta_padding_top']).'px' : '8px';
    $cta_padding_right = !empty($theme['cta_padding_right']) ? wpmm_unit_to_int($theme['cta_padding_right']).'px' : '35px';
    $cta_padding_bottom = !empty($theme['cta_padding_bottom']) ? wpmm_unit_to_int($theme['cta_padding_bottom']).'px' : '8px';
    $cta_padding_left = !empty($theme['cta_padding_left']) ? wpmm_unit_to_int($theme['cta_padding_left']).'px' : '35px';

    $cta_margin_top = !empty($theme['cta_margin_top']) ? wpmm_unit_to_int($theme['cta_margin_top']).'px' : '0';
    $cta_margin_right = !empty($theme['cta_margin_right']) ? wpmm_unit_to_int($theme['cta_margin_right']).'px' : '0';
    $cta_margin_bottom = !empty($theme['cta_margin_bottom']) ? wpmm_unit_to_int($theme['cta_margin_bottom']).'px' : '0';
    $cta_margin_left = !empty($theme['cta_margin_left']) ? wpmm_unit_to_int($theme['cta_margin_left']).'px' : '0';


    # hover style
    $cta_btn_bg = !empty($theme['cta_btn_bg']) ? $theme['cta_btn_bg'] : '#288feb';
    $cta_btn_hover_bg = !empty($theme['cta_btn_hover_bg']) ? $theme['cta_btn_hover_bg'] : '#288feb';
    $cta_btn_border_radius_top_left_hover = !empty($theme['cta_btn_border_radius_top_left_hover']) ? wpmm_unit_to_int($theme['cta_btn_border_wpmm_unit_to_int(radius_top_left_hover']).'px' : $cta_btn_border_radius_top_left;
    $cta_btn_radius_top_right_hover = !empty($theme['cta_btn_radius_top_right_hover']) ? wpmm_unit_to_int($theme['cta_btn_radius_top_right_hover']).'px' : $cta_btn_radius_top_right;
    $cta_radius_bottom_left_hover = !empty($theme['cta_radius_bottom_left_hover']) ? wpmm_unit_to_int($theme['cta_radius_bottom_left_hover']).'px' : $cta_radius_bottom_left;
    $cta_radius_bottom_right_hover = !empty($theme['cta_radius_bottom_right_hover']) ? wpmm_unit_to_int($theme['cta_radius_bottom_right_hover']).'px' : $cta_radius_bottom_right;

    // style
    $style .= "#$navbar_id .wpmm-nav-wrap ul.wp-megamenu li.wpmm-cta-button > a{
        color: $cta_btn_color;
        background: $cta_btn_bg;
        font-family: $cta_btn_font;
        font-size: $cta_btn_font_size;
        font-weight: $cta_btn_font_weight;
        line-height: $cta_btn_line_height;
        text-transform: $cta_btn_text_transform;
        letter-spacing: $cta_btn_letter_spacing;
        border-width: $cta_btn_top_border_width $cta_btn_right_border_width $cta_btn_bottom_border_width $cta_btn_left_border_width;
        border-color: $cta_btn_border_color;
        border-style: $cta_btn_border_type;
        border-top-left-radius: $cta_btn_border_radius_top_left;
        border-top-right-radius: $cta_btn_radius_top_right;
        border-bottom-left-radius: $cta_radius_bottom_left;
        border-bottom-right-radius: $cta_radius_bottom_right;
        padding-top: $cta_padding_top;
        padding-right: $cta_padding_right;
        padding-bottom: $cta_padding_bottom;
        padding-left: $cta_padding_left;
        margin-top: $cta_margin_top;
        margin-right: $cta_margin_right;
        margin-bottom: $cta_margin_bottom;
        margin-left: $cta_margin_left;
    }";

    // hover style
    $style .= "#$navbar_id .wpmm-nav-wrap ul.wp-megamenu li.wpmm-cta-button > a:hover{
        color: $cta_btn_hover_color;
        background-color: $cta_btn_hover_bg;
        border-color: $cta_btn_border_hover_color;
        border-top-left-radius: $cta_btn_border_radius_top_left_hover;
        border-top-right-radius: $cta_btn_radius_top_right_hover;
        border-bottom-left-radius: $cta_radius_bottom_left_hover;
        border-bottom-right-radius: $cta_radius_bottom_right_hover;
    }";

    return $style;
}