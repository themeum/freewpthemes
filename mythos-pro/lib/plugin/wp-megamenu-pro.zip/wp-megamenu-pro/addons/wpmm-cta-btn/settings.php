<?php


add_action('wpmm_settings_tab_menu_before', function () {
    $menu_item = '<li><a href="#tabs-116">' . __('CTA Button', 'wp-megamenu') . '<sup class="badge">pro</sup></a></li>';
    echo $menu_item;
}, 11);

add_action('wpmm_settings_tab_content', function ($theme_id) {

    ob_start();
    ?>
    <div id="tabs-116">
        <table class="form-table wpmm-option-table wpmm-main-setting-table">
            <tr class="wpmm-fields-header wpmm-field-group wpmm-table-divider">
                <th colspan="2"> <?php _e('CTA Button', 'wp-megamenu'); ?> </th>
            </tr>
            <!-- @ Start cta button -->

            <tr class=" wpmm-field-group">
                <th>
                    <?php _e('Call to Action Button', 'wp-megamenu'); ?>
                </th>
                <td>
                    <div class="form_item">
                        <label>
                            <input
                                type="text"
                                name="wpmm_theme_option[cta_btn_text]"
                                value="<?php echo get_wpmm_theme_option('cta_btn_text', $theme_id); ?>"
                            />
                            <p class="field-description"><?php _e('CTA Button Text.', 'wp-megamenu'); ?></p>
                        </label>
                        <label>
                            <input
                                type="text"
                                name="wpmm_theme_option[cta_btn_link]"
                                value="<?php echo get_wpmm_theme_option('cta_btn_link', $theme_id); ?>"
                            />
                            <p class="field-description"><?php _e('CTA Button Text.', 'wp-megamenu'); ?></p>
                        </label>
                    </div>
                </td>
            </tr>
            <tr class=" wpmm-field-group">
                <th>
                    <?php _e('Button Color & Background', 'wp-megamenu'); ?>
                </th>
                <td>

                    <table>
                        <tr>
                            <td>
                                <div>
                                    <h5><?php _e('Color', 'wp-megamenu'); ?></h5>
                                    <label class="text_and_input">
                                        <input type="text" name="wpmm_theme_option[cta_btn_color]" value="<?php echo get_wpmm_theme_option('cta_btn_color', $theme_id); ?>" class="color-picker" data-alpha="true" />
                                    </label>
                                </div>
                                <div>
                                    <h5><?php _e('Hover Color', 'wp-megamenu'); ?></h5>
                                    <label class="text_and_input">
                                        <input type="text" name="wpmm_theme_option[cta_btn_hover_color]" value="<?php echo get_wpmm_theme_option('cta_btn_hover_color', $theme_id); ?>" class="color-picker" data-alpha="true" />
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <h5><?php _e('Background', 'wp-megamenu'); ?></h5>
                                    <label class="text_and_input">
                                        <input type="text" name="wpmm_theme_option[cta_btn_bg]" value="<?php echo get_wpmm_theme_option('cta_btn_bg', $theme_id); ?>" class="color-picker" data-alpha="true" />
                                    </label>
                                </div>
                                <div>
                                    <h5><?php _e('Hover Background', 'wp-megamenu'); ?></h5>
                                    <label class="text_and_input">
                                        <input type="text" name="wpmm_theme_option[cta_btn_hover_bg]" value="<?php echo get_wpmm_theme_option('cta_btn_hover_bg', $theme_id); ?>" class="color-picker" data-alpha="true" />
                                    </label>
                                </div>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class=" wpmm-field-group">
                <th>
                    <div>
                        <h4><?php _e('Button Typography', 'wp-megamenu'); ?></h4>
                    </div>
                </th>

                <td>
                    <div>
                        <label class="text_and_input">
                            <span class="wpmm_labe_text"><?php _e('Font', 'wp-megamenu'); ?></span>

                            <?php
                            $google_fonts = wpmm_get_google_fonts();
                            $cta_btn_saved_font = get_wpmm_theme_option('cta_btn_font', $theme_id);
                            ?>
                            <select name="wpmm_theme_option[cta_btn_font]" class="select2">
                                <option value=""><?php _e('Select font', 'wp-megamenu'); ?></option>
                                <?php
                                foreach ($google_fonts as $font){
                                    $is_cta_btn_selected = ($cta_btn_saved_font === $font) ? ' selected="selected" ':'';
                                    echo "<option value='{$font}' {$is_cta_btn_selected} >{$font}</option>";
                                }
                                ?>
                            </select>
                        </label>
                        <p class="field-description"><?php echo sprintf(__('%d google fonts available', 'wp-megamenu'), count($google_fonts)); ?></p>
                    </div>

                    <div>
                        <label class="text_and_input">
                            <span class="wpmm_labe_text"><?php _e('Font Size', 'wp-megamenu'); ?> </span>
                            <?php
                            $cta_btn_font_size = get_wpmm_theme_option('cta_btn_font_size', $theme_id);
                            if( ! $cta_btn_font_size){
                                $cta_btn_font_size = '14px';
                            }
                            ?>
                            <input type="text" name="wpmm_theme_option[cta_btn_font_size]" value="<?php echo $cta_btn_font_size; ?>" data-alpha="true" placeholder="14px" />
                        </label>
                    </div>
                    <div>
                        <label class="text_and_input">
                            <span class="wpmm_labe_text"> <?php _e('Font Weight', 'wp-megamenu'); ?> </span>

                            <?php
                            $cta_btn_font_weight = get_wpmm_theme_option('cta_btn_font_weight', $theme_id);
                            if( ! $cta_btn_font_weight){
                                $cta_btn_font_weight = '400';
                            }
                            ?>
                            <select name="wpmm_theme_option[cta_btn_font_weight]">
                                <option value="normal" <?php selected($cta_btn_font_weight, 'normal') ?> > <?php _e('Normal', 'wp-megamenu'); ?> </option>
                                <option value="bold" <?php selected($cta_btn_font_weight, 'bold') ?> > <?php _e('Bold', 'wp-megamenu'); ?> </option>
                                <option value="bolder" <?php selected($cta_btn_font_weight, 'bolder') ?> > <?php _e('Bolder', 'wp-megamenu'); ?> </option>
                                <option value="lighter" <?php selected($cta_btn_font_weight, 'lighter') ?> > <?php _e('Lighter', 'wp-megamenu'); ?> </option>
                                <option value="100" <?php selected($cta_btn_font_weight, '100') ?> > <?php _e('100', 'wp-megamenu'); ?> </option>
                                <option value="200" <?php selected($cta_btn_font_weight, '200') ?> > <?php _e('200', 'wp-megamenu'); ?> </option>
                                <option value="300" <?php selected($cta_btn_font_weight, '300') ?> > <?php _e('300', 'wp-megamenu'); ?> </option>
                                <option value="400" <?php selected($cta_btn_font_weight, '400') ?> > <?php _e('400', 'wp-megamenu'); ?> </option>
                                <option value="500" <?php selected($cta_btn_font_weight, '500') ?> > <?php _e('500', 'wp-megamenu'); ?> </option>
                                <option value="600" <?php selected($cta_btn_font_weight, '600') ?> > <?php _e('600', 'wp-megamenu'); ?> </option>
                                <option value="700" <?php selected($cta_btn_font_weight, '700') ?> > <?php _e('700', 'wp-megamenu'); ?> </option>
                                <option value="800" <?php selected($cta_btn_font_weight, '800') ?> > <?php _e('800', 'wp-megamenu'); ?> </option>
                                <option value="900" <?php selected($cta_btn_font_weight, '900') ?> > <?php _e('900', 'wp-megamenu'); ?> </option>
                            </select>

                        </label>
                    </div>

                    <div>
                        <label class="text_and_input">
                            <span class="wpmm_labe_text"> <?php _e('Line Height', 'wp-megamenu'); ?> </span>

                            <?php
                            $cta_btn_line_height = get_wpmm_theme_option('cta_btn_line_height', $theme_id);
                            if( ! $cta_btn_line_height){
                                $cta_btn_line_height = '';
                            }
                            ?>
                            <input type="text" name="wpmm_theme_option[cta_btn_line_height]" value="<?php echo $cta_btn_line_height; ?>" data-alpha="true" placeholder="24px" />
                        </label>
                    </div>

                    <div>
                        <label class="text_and_input">
                            <span class="wpmm_labe_text"> <?php _e('Text Transform', 'wp-megamenu'); ?> </span>

                            <select name="wpmm_theme_option[cta_btn_text_transform]">
                                <option value="uppercase" <?php selected(get_wpmm_theme_option('cta_btn_text_transform', $theme_id), 'uppercase') ?> > <?php _e('Uppercase', 'wp-megamenu'); ?> </option>
                                <option value="lowercase" <?php selected(get_wpmm_theme_option('cta_btn_text_transform', $theme_id), 'lowercase') ?> > <?php _e('Lowercase', 'wp-megamenu'); ?> </option>
                                <option value="capitalize" <?php selected(get_wpmm_theme_option('cta_btn_text_transform', $theme_id), 'capitalize') ?> > <?php _e('Capitalize', 'wp-megamenu'); ?> </option>
                            </select>

                        </label>
                    </div>

                    <div>
                        <label class="text_and_input">
                            <span class="wpmm_labe_text"> <?php _e('Letter Spacing', 'wp-megamenu'); ?> </span>

                            <?php
                            $cta_btn_letter_spacing = get_wpmm_theme_option('cta_btn_letter_spacing', $theme_id);
                            if( ! $cta_btn_letter_spacing){
                                $cta_btn_letter_spacing = '';
                            }
                            ?>
                            <input type="text" name="wpmm_theme_option[cta_btn_letter_spacing]" value="<?php echo $cta_btn_letter_spacing; ?>" data-alpha="true" placeholder="0px"/>
                        </label>
                    </div>
                </td>
            </tr>

            <tr class="wpmm-field wpmm-field-group">
                <th>
                    <?php _e('Item Padding', 'wp-megamenu'); ?>
                </th>
                <td>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <?php
                            $cta_padding_top = get_wpmm_theme_option('cta_padding_top', $theme_id);
                            if( ! $cta_padding_top){
                                $cta_padding_top = '';
                            }
                            ?>
                            <p><?php _e('Top', 'wp-megamenu'); ?></p>
                            <input type='text' name='wpmm_theme_option[cta_padding_top]' value="<?php echo $cta_padding_top; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Right', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_padding_right = get_wpmm_theme_option('cta_padding_right', $theme_id);
                            if( ! $cta_padding_right){
                                $cta_padding_right = '';
                            }
                            ?>

                            <input type='text' name='wpmm_theme_option[cta_padding_right]' value="<?php echo $cta_padding_right; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Bottom', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_padding_bottom = get_wpmm_theme_option('cta_padding_bottom', $theme_id);
                            if( ! $cta_padding_bottom){
                                $cta_padding_bottom = '';
                            }
                            ?>

                            <input type='text' name='wpmm_theme_option[cta_padding_bottom]' value="<?php echo $cta_padding_bottom; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Left', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_padding_left = get_wpmm_theme_option('cta_padding_left', $theme_id);
                            if( ! $cta_padding_left){
                                $cta_padding_left = '';
                            }
                            ?>

                            <input type='text' name='wpmm_theme_option[cta_padding_left]' value="<?php echo $cta_padding_left; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <p class="field-description"><?php _e('Set padding to the menu bar.', 'wp-megamenu'); ?></p>
                </td>
            </tr>
            <tr class="wpmm-field wpmm-field-group">
                <th>
                    <?php _e('Item margin', 'wp-megamenu'); ?>
                </th>
                <td>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <?php
                            $cta_margin_top = get_wpmm_theme_option('cta_margin_top', $theme_id);
                            if( ! $cta_margin_top){
                                $cta_margin_top = '';
                            }
                            ?>
                            <p><?php _e('Top', 'wp-megamenu'); ?></p>
                            <input type='text' name='wpmm_theme_option[cta_margin_top]' value="<?php echo $cta_margin_top; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Right', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_margin_right = get_wpmm_theme_option('cta_margin_right', $theme_id);
                            if( ! $cta_margin_right){
                                $cta_margin_right = '';
                            }
                            ?>

                            <input type='text' name='wpmm_theme_option[cta_margin_right]' value="<?php echo $cta_margin_right; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Bottom', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_margin_bottom = get_wpmm_theme_option('cta_margin_bottom', $theme_id);
                            if( ! $cta_margin_bottom){
                                $cta_margin_bottom = '';
                            }
                            ?>

                            <input type='text' name='wpmm_theme_option[cta_margin_bottom]' value="<?php echo $cta_margin_bottom; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Left', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_margin_left = get_wpmm_theme_option('cta_margin_left', $theme_id);
                            if( ! $cta_margin_left){
                                $cta_margin_left = '';
                            }
                            ?>

                            <input type='text' name='wpmm_theme_option[cta_margin_left]' value="<?php echo $cta_margin_left; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <p class="field-description"><?php _e('Set margin to the menu bar.', 'wp-megamenu'); ?></p>
                </td>
            </tr>

            <tr class="wpmm-field wpmm-field-group">
                <th>
                    <?php _e('CTA Button Border', 'wp-megamenu'); ?>
                </th>
                <td>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Top Width', 'wp-megamenu'); ?></p>
                            <input type='text' name='wpmm_theme_option[cta_btn_top_border_width]' value="<?php echo get_wpmm_theme_option('cta_btn_top_border_width', $theme_id); ?>" placeholder="1px" />
                        </label>
                    </div>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Right Width', 'wp-megamenu'); ?></p>
                            <input type='text' name='wpmm_theme_option[cta_btn_right_border_width]' value="<?php echo get_wpmm_theme_option('cta_btn_right_border_width', $theme_id); ?>" placeholder="1px" />
                        </label>
                    </div>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Bottom Width', 'wp-megamenu'); ?></p>
                            <input type='text' name='wpmm_theme_option[cta_btn_bottom_border_width]' value="<?php echo get_wpmm_theme_option('cta_btn_bottom_border_width', $theme_id); ?>" placeholder="1px" />
                        </label>
                    </div>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Left Width', 'wp-megamenu'); ?></p>
                            <input type='text' name='wpmm_theme_option[cta_btn_left_border_width]' value="<?php echo get_wpmm_theme_option('cta_btn_left_border_width', $theme_id); ?>" placeholder="1px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Type', 'wp-megamenu'); ?></p>
                            <select name="wpmm_theme_option[cta_btn_border_type]">
                                <option value="none" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'none'); ?> > <?php _e('None', 'wp-megamenu'); ?> </option>
                                <option value="solid" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'solid'); ?> > <?php _e('Solid', 'wp-megamenu'); ?> </option>
                                <option value="dashed" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'dashed') ?> > <?php _e('Dashed', 'wp-megamenu'); ?> </option>
                                <option value="dotted" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'dotted') ?> >  <?php _e('Dotted', 'wp-megamenu'); ?> </option>
                                <option value="double" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'double') ?> > <?php _e('Double', 'wp-megamenu'); ?> </option>
                                <option value="groove" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'groove') ?> > <?php _e('Groove', 'wp-megamenu'); ?> </option>
                                <option value="ridge" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'ridge') ?> >  <?php _e('Ridge', 'wp-megamenu'); ?> </option>
                                <option value="inset" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'inset') ?> >  <?php _e('Inset', 'wp-megamenu'); ?> </option>
                                <option value="outset" <?php selected(get_wpmm_theme_option('cta_btn_border_type', $theme_id), 'outset') ?> >  <?php _e('Outset', 'wp-megamenu'); ?> </option>
                            </select>
                        </label>
                    </div>
                    <div>
                        <h5><?php _e('Border Color', 'wp-megamenu'); ?></h5>
                        <label>
                            <input type="text" name="wpmm_theme_option[cta_btn_border_color]" value="<?php echo get_wpmm_theme_option('cta_btn_border_color', $theme_id); ?>" class="color-picker" data-alpha="true" />
                        </label>
                        <h5><?php _e('Border Hover Color', 'wp-megamenu'); ?></h5>
                        <label>
                            <input type="text" name="wpmm_theme_option[cta_btn_border_hover_color]" value="<?php echo get_wpmm_theme_option('cta_btn_border_hover_color', $theme_id); ?>" class="color-picker" data-alpha="true" />
                        </label>
                    </div>

                    <p class="field-description"><?php _e('Set border width and color.', 'wp-megamenu'); ?></p>
                </td>
            </tr>

            <tr class="wpmm-field wpmm-field-group">
                <th>
                    <?php _e('CTA Button Border Radius', 'wp-megamenu'); ?>
                </th>

                <td>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Top Left', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_btn_border_radius_top_left = get_wpmm_theme_option('cta_btn_border_radius_top_left', $theme_id);
                            if( ! $cta_btn_border_radius_top_left){
                                $cta_btn_border_radius_top_left = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_btn_border_radius_top_left]' value="<?php echo $cta_btn_border_radius_top_left; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Top Right', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_btn_radius_top_right = get_wpmm_theme_option('cta_btn_radius_top_right', $theme_id);
                            if( ! $cta_btn_radius_top_right){
                                $cta_btn_radius_top_right = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_btn_radius_top_right]' value="<?php echo $cta_btn_radius_top_right; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Bottom Left', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_radius_bottom_left = get_wpmm_theme_option('cta_radius_bottom_left', $theme_id);
                            if( ! $cta_radius_bottom_left){
                                $cta_radius_bottom_left = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_radius_bottom_left]'
                                   value="<?php echo $cta_radius_bottom_left; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Bottom Right', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_radius_bottom_right = get_wpmm_theme_option('cta_radius_bottom_right', $theme_id);
                            if( ! $cta_radius_bottom_right){
                                $cta_radius_bottom_right = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_radius_bottom_right]'
                                   value="<?php echo $cta_radius_bottom_right; ?>" placeholder="0px" />
                        </label>
                    </div>
                    <p class="field-description"><?php _e('Set border radius on the menu bar.', 'wp-megamenu'); ?></p>
                </td>
            </tr>
            <tr class="wpmm-field wpmm-field-group">
                <th>
                    <?php _e('Hover Border Radius', 'wp-megamenu'); ?>
                </th>

                <td>
                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Top Left', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_btn_border_radius_top_left_hover = get_wpmm_theme_option('cta_btn_border_radius_top_left_hover', $theme_id);
                            if( ! $cta_btn_border_radius_top_left_hover){
                                $cta_btn_border_radius_top_left_hover = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_btn_border_radius_top_left_hover]' value="<?php echo $cta_btn_border_radius_top_left_hover; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Top Right', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_btn_radius_top_right_hover = get_wpmm_theme_option('cta_btn_radius_top_right_hover', $theme_id);
                            if( ! $cta_btn_radius_top_right_hover){
                                $cta_btn_radius_top_right_hover = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_btn_radius_top_right_hover]' value="<?php echo $cta_btn_radius_top_right_hover; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Bottom Left', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_radius_bottom_left_hover = get_wpmm_theme_option('cta_radius_bottom_left_hover', $theme_id);
                            if( ! $cta_radius_bottom_left_hover){
                                $cta_radius_bottom_left_hover = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_radius_bottom_left_hover]'
                                   value="<?php echo $cta_radius_bottom_left_hover; ?>" placeholder="0px" />
                        </label>
                    </div>

                    <div class="wpmm_theme_arrow_segment">
                        <label>
                            <p><?php _e('Bottom Right', 'wp-megamenu'); ?></p>

                            <?php
                            $cta_radius_bottom_right_hover = get_wpmm_theme_option('cta_radius_bottom_right_hover', $theme_id);
                            if( ! $cta_radius_bottom_right_hover){
                                $cta_radius_bottom_right_hover = '';
                            }
                            ?>
                            <input type='text' name='wpmm_theme_option[cta_radius_bottom_right_hover]'
                                   value="<?php echo $cta_radius_bottom_right_hover; ?>" placeholder="0px" />
                        </label>
                    </div>
                    <p class="field-description"><?php _e('Set border radius on the menu bar.', 'wp-megamenu'); ?></p>
                </td>
            </tr>
            <!-- @ End cta button -->
        </table>
    </div>
    <?php

    $menu_content = ob_get_contents();
    ob_end_clean();
    echo $menu_content;
});
