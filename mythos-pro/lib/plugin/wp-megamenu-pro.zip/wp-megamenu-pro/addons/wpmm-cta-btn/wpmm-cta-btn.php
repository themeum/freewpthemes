<?php

// menu settings
include_once('settings.php');
include_once('styles.php');