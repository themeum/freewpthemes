<?php

include_once('settings.php');
include_once('styles.php');

