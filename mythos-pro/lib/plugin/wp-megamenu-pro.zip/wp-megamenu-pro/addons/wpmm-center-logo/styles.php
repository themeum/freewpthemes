<?php

add_filter('wpmm_generated_css', 'wpmm_pro_center_logo_styles', 10, 2);

function wpmm_pro_center_logo_styles($style) {
    global $wpdb;

    $menu_layout_query = $wpdb->get_results("select * from {$wpdb->postmeta} WHERE meta_key = 'wpmm_layout' ");

    if (!empty($menu_layout_query)) {
        foreach ($menu_layout_query as $layout) {
            //$is_nav_menu_post = get_post($layout->post_id);
            $layout_unserialize = maybe_unserialize($layout->meta_value);
            $mo = !empty($layout_unserialize['options']) ? $layout_unserialize['options'] : array();
            if (!empty($mo['mark_as_logo']) && $mo['mark_as_logo'] === 'enable') {

                $style .= ".wp-megamenu-item-{$layout->post_id} a{";
                $style .= "position: relative !important;";
                if (!empty($mo['item_logo_position'])) {
                    $style .= "top: {$mo['item_logo_position']} !important;";
                }

                if (!empty($mo['item_logo_margin_top'])) {
                    $style .= "margin-top: {$mo['item_logo_margin_top']} !important;";
                }
                if (!empty($mo['item_logo_margin_right'])) {
                    $style .= "margin-right: {$mo['item_logo_margin_right']} !important;";
                }

                if (!empty($mo['item_logo_margin_bottom'])) {
                    $style .= "margin-bottom: {$mo['item_logo_margin_bottom']} !important;";
                }
                if (!empty($mo['item_logo_margin_left'])) {
                    $style .= "margin-left: {$mo['item_logo_margin_left']} !important;";
                }

                if (!empty($mo['item_logo_padding_top'])) {
                    $style .= "padding-top: {$mo['item_logo_padding_top']} !important;";
                }
                if (!empty($mo['item_logo_padding_right'])) {
                    $style .= "padding-right: {$mo['item_logo_padding_right']} !important;";
                }

                if (!empty($mo['item_logo_padding_bottom'])) {
                    $style .= "padding-bottom: {$mo['item_logo_padding_bottom']} !important;";
                }
                if (!empty($mo['item_logo_padding_left'])) {
                    $style .= "padding-left: {$mo['item_logo_padding_left']} !important;";
                }

                //For Text Logo
                if ($mo['item_logo_type'] === 'text') {
                    if (!empty($mo['text_logo_google_font'])) {
                        //font-family: 'Abel';
                        $style .= "font-family: '{$mo['text_logo_google_font']}' !important;";
                    }
                    if (!empty($mo['text_logo_font_weight'])) {
                        $style .= "font-weight: {$mo['text_logo_font_weight']} !important;";
                    }
                    if (!empty($mo['text_logo_font_size'])) {
                        $style .= "font-size: {$mo['text_logo_font_size']} !important;";
                    }
                    if (!empty($mo['text_logo_line_height'])) {
                        $style .= "line-height: {$mo['text_logo_line_height']} !important;";
                    }
                    if (!empty($mo['text_logo_case'])) {
                        $style .= "text-transform: {$mo['text_logo_case']} !important;";
                    }
                    if (!empty($mo['text_logo_letter_spacing'])) {
                        $style .= "letter-spacing: {$mo['text_logo_letter_spacing']} !important;";
                    }
                    if (!empty($mo['text_logo_color'])) {
                        $style .= "color: {$mo['text_logo_color']} !important;";
                    }
                }

                $style .= "}";
                if (!empty($mo['item_logo_max_height'])) {
                    $style .= ".wp-megamenu-item-{$layout->post_id} a img{";
                    $style .= "max-height: {$mo['item_logo_max_height']} !important;";
                    $style .= "width: auto !important;";
                    $style .= "}";
                }


                //Hide Menu item as logo in mobile menu
                $style .= "@media only screen and (max-width: 768px) {";
                $style .= ".wp-megamenu-item-logo-{$layout->post_id}{ ";
                $style .= "display: none !important;";
                $style .= "}";
                $style .= "}";

            }

        }
    }

    return $style;

}