<?php


add_action('menu_item_settings', 'logo_center_settings', 10, 2);

function logo_center_settings($menu_item_id) {
    $menu_item_depth = (int) sanitize_text_field($_POST['menu_item_depth']);
    ob_start();

    ?>

    <tr>
        <td colspan="2" style="width: 100%;">
            <div class="wpmm-item-button-form-wrap">

                <?php if ($menu_item_depth == 0){ ?>

                    <h3><?php _e('Make Center Logo', 'wp-megamenu'); ?></h3>

                    <table class="form-table wpmm-option-table wpmm-main-setting-table">

                        <tr class="wpmm-field wpmm-field-group">
                            <td>
                                <?php _e('Enable', 'wp-megamenu'); ?>
                            </td>
                            <td>

                                <?php
                                $mark_as_logo = wpmm_get_item_settings($menu_item_id, 'mark_as_logo', 'disable');
                                ?>

                                <label>
                                    <input type="radio" name="options[mark_as_logo]" value="enable" <?php checked($mark_as_logo, 'enable'); ?>> <?php _e('Enable', 'wp-megamenu'); ?>
                                </label>

                                <label>
                                    <input type="radio" name="options[mark_as_logo]" value="disable"  <?php checked($mark_as_logo, 'disable'); ?> > <?php _e('Disable', 'wp-megamenu'); ?>
                                </label>
                                <p class="field-description"> <?php _e('Enable this item as logo', 'wp-megamenu'); ?></p>
                            </td>
                        </tr>

                        <tr class="wpmm-field wpmm-field-group">
                            <td>
                                <?php _e('Logo Type', 'wp-megamenu'); ?>
                            </td>
                            <td>
                                <label>
                                    <?php
                                    $item_logo_type = wpmm_get_item_settings($menu_item_id, 'item_logo_type', 'image');
                                    ?>
                                    <input type="radio" name="options[item_logo_type]" value="image" <?php checked($item_logo_type, 'image') ?>> <?php _e('Image', 'wp-megamenu'); ?>
                                </label>

                                <label>
                                    <input type="radio" name="options[item_logo_type]" value="text"  <?php checked(wpmm_get_item_settings($menu_item_id, 'item_logo_type'), 'text') ?> > <?php _e('Text', 'wp-megamenu'); ?>
                                </label>
                                <p class="field-description"> <?php _e('Choose logo type', 'wp-megamenu'); ?></p>
                            </td>
                        </tr>


                        <tr>
                            <td><?php _e('Upload Logo', 'wp-megamenu'); ?></td>
                            <td>
                                <div class="wpmm-image-upload-wrap">
                                    <?php $brand_logo = wpmm_get_item_settings($menu_item_id, 'item_logo_url'); ?>
                                    <input type="button" class="wpmm_upload_image_button button" value="<?php _e( 'Upload image', 'wp-megamenu' ); ?>" /> <br />
                                    <div class="wpmm_upload_image_preview_wrap">
                                        <?php
                                        if ( ! empty($brand_logo)){
                                            echo '<img src="'.$brand_logo.'" class="wpmm_upload_image_preview" >';
                                            echo '<a href="javascript:;" class="wpmm_img_delete"><i class="fa fa-trash-o"></i> </a>';
                                        }
                                        ?>
                                    </div>
                                    <input type="text" class="wpmm_upload_image_field" name="options[item_logo_url]" value="<?php echo $brand_logo; ?>" />
                                    <p class="field-description"><?php _e('Item Logo URL', 'wp-megamenu'); ?></p>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Logo Text', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $item_logo_text = wpmm_get_item_settings($menu_item_id,'item_logo_text', '');
                                    ?>
                                    <input type="text" name="options[item_logo_text]" value="<?php echo $item_logo_text; ?>" placeholder="<?php _e('Logo Text', 'wp-megamenu'); ?>"/>
                                </label>

                                <p class="field-description"><?php _e('Set logo text instead of image', 'wp-megamenu');?></p>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Select Google Font', 'wp-megamenu'); ?>
                            </td>

                            <td>

                                <label class="text_and_input">
                                    <?php
                                    $google_fonts = wpmm_get_google_fonts();
                                    $text_logo_google_font = wpmm_get_item_settings($menu_item_id,'text_logo_google_font');
                                    ?>
                                    <select name="options[text_logo_google_font]" class="select2">
                                        <option value=""><?php _e('Select font', 'wp-megamenu'); ?></option>
                                        <?php
                                        foreach ($google_fonts as $font){
                                            echo "<option value='{$font}' ".selected($text_logo_google_font, $font)." >{$font}</option>";
                                        }
                                        ?>
                                    </select>
                                </label>

                                <p class="field-description"><?php echo sprintf(__('%d google fonts available', 'wp-megamenu'), count($google_fonts)); ?></p>

                            </td>
                        </tr>




                        <tr>
                            <td>
                                <?php _e('Logo Position', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $item_logo_position = wpmm_get_item_settings($menu_item_id,'item_logo_position', '');
                                    ?>
                                    <input type="text" name="options[item_logo_position]" value="<?php echo $item_logo_position; ?>"  placeholder="<?php _e('Logo Position', 'wp-megamenu'); ?>"/>
                                </label>

                                <p class="field-description"><?php _e('You can set negetive value also, ex: -100px', 'wp-megamenu');?></p>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Maximum Heights', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $item_logo_max_height = wpmm_get_item_settings($menu_item_id,'item_logo_max_height');
                                    if( ! $item_logo_max_height){
                                        $item_logo_max_height = '30px';
                                    }
                                    ?>
                                    <input type="text" name="options[item_logo_max_height]" value="<?php echo $item_logo_max_height; ?>" placeholder="30px"/>
                                </label>

                                <p class="field-description"><?php _e('Set logo image height', 'wp-megamenu');?></p>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Width', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $item_logo_max_width = wpmm_get_item_settings($menu_item_id,'item_logo_max_width', 'auto');
                                    ?>
                                    <input type="text" name="options[item_logo_max_width]" value="<?php echo $item_logo_max_width; ?>" placeholder="30px"/>
                                </label>

                                <p class="field-description"><?php _e('Set logo image width', 'wp-megamenu');?></p>
                            </td>
                        </tr>

                        <tr class="wpmm-field wpmm-field-group">
                            <td>
                                <?php _e('Margin', 'wp-megamenu'); ?>
                            </td>
                            <td>
                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Top', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_margin_top = wpmm_get_item_settings($menu_item_id,'item_logo_margin_top');
                                        if( ! $item_logo_margin_top){
                                            $item_logo_margin_top = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_margin_top]' value="<?php echo $item_logo_margin_top; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Right', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_margin_right = wpmm_get_item_settings($menu_item_id,'item_logo_margin_right');
                                        if( ! $item_logo_margin_right){
                                            $item_logo_margin_right = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_margin_right]' value="<?php echo $item_logo_margin_right; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Bottom', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_margin_bottom = wpmm_get_item_settings
                                        ($menu_item_id,'item_logo_margin_bottom');
                                        if( ! $item_logo_margin_bottom){
                                            $item_logo_margin_bottom = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_margin_bottom]' value="<?php echo $item_logo_margin_bottom; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Left', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_margin_left = wpmm_get_item_settings($menu_item_id,'item_logo_margin_left');
                                        if( ! $item_logo_margin_left){
                                            $item_logo_margin_left = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_margin_left]' value="<?php echo $item_logo_margin_left; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <p class="field-description"><?php _e('Set padding to menu bar.', 'wp-megamenu'); ?></p>
                            </td>
                        </tr>

                        <tr class="wpmm-field wpmm-field-group">
                            <td>
                                <?php _e('Padding', 'wp-megamenu'); ?>
                            </td>
                            <td>

                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Top', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_padding_top = wpmm_get_item_settings($menu_item_id,'item_logo_padding_top');
                                        if( ! $item_logo_padding_top){
                                            $item_logo_padding_top = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_padding_top]' value="<?php echo $item_logo_padding_top; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Right', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_padding_right = wpmm_get_item_settings($menu_item_id,'item_logo_padding_right');
                                        if( ! $item_logo_padding_right){
                                            $item_logo_padding_right = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_padding_right]' value="<?php echo $item_logo_padding_right; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Bottom', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_padding_bottom = wpmm_get_item_settings
                                        ($menu_item_id,'item_logo_padding_bottom');
                                        if( ! $item_logo_padding_bottom){
                                            $item_logo_padding_bottom = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_padding_bottom]' value="<?php echo $item_logo_padding_bottom; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <div class="wpmm_theme_arrow_segment">
                                    <label>
                                        <p><?php _e('Left', 'wp-megamenu'); ?></p>

                                        <?php
                                        $item_logo_padding_left = wpmm_get_item_settings($menu_item_id,'item_logo_padding_left');
                                        if( ! $item_logo_padding_left){
                                            $item_logo_padding_left = '';
                                        }
                                        ?>
                                        <input type='text' name='options[item_logo_padding_left]' value="<?php echo $item_logo_padding_left; ?>" placeholder="0px" />
                                    </label>
                                </div>

                                <p class="field-description"><?php _e('Set padding to menu bar.', 'wp-megamenu'); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Font weight', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $text_logo_font_weight = wpmm_get_item_settings($menu_item_id,'text_logo_font_weight', '');
                                    ?>
                                    <input type="text" name="options[text_logo_font_weight]" value="<?php echo $text_logo_font_weight; ?>" placeholder="300"/>

                                    <p class="field-description"><?php _e('Set font weight, applicable for text logo.', 'wp-megamenu'); ?></p>
                                </label>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Font size', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $text_logo_font_size = wpmm_get_item_settings($menu_item_id,'text_logo_font_size', '30px');
                                    ?>
                                    <input type="text" name="options[text_logo_font_size]" value="<?php echo $text_logo_font_size; ?>" placeholder="30px"/>

                                    <p class="field-description"><?php _e('Set font size, applicable for text logo.', 'wp-megamenu'); ?></p>
                                </label>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Line height', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $text_logo_line_height = wpmm_get_item_settings($menu_item_id,'text_logo_line_height', '30px');
                                    ?>
                                    <input type="text" name="options[text_logo_line_height]" value="<?php echo $text_logo_line_height; ?>" placeholder="30px"/>

                                    <p class="field-description"><?php _e('Set line height, applicable for text logo.', 'wp-megamenu'); ?></p>
                                </label>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Text logo case', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $text_logo_case = wpmm_get_item_settings($menu_item_id,'text_logo_case', 'uppercase');
                                    ?>

                                    <select name="options[text_logo_case]" >
                                        <option value="uppercase" <?php selected($text_logo_case, 'uppercase'); ?> ><?php _e('UPPERCASE', 'wp-megamenu'); ?></option>
                                        <option value="lowercase" <?php selected($text_logo_case, 'lowercase'); ?>><?php _e('lowercase', 'wp-megamenu'); ?></option>
                                        <option value="capitalize" <?php selected($text_logo_case, 'capitalize'); ?>><?php _e('capitalize', 'wp-megamenu'); ?></option>
                                        <option value="inherit" <?php selected($text_logo_case, 'inherit'); ?>><?php _e('inherit', 'wp-megamenu'); ?></option>
                                        <option value="none" <?php selected($text_logo_case, 'none'); ?>><?php _e('none', 'wp-megamenu'); ?></option>
                                    </select>

                                    <p class="field-description"><?php _e('Set text logo case', 'wp-megamenu');
                                        ?></p>
                                </label>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <?php _e('Letter spacing', 'wp-megamenu'); ?>
                            </td>

                            <td>
                                <label class="text_and_input">
                                    <?php
                                    $text_logo_letter_spacing = wpmm_get_item_settings($menu_item_id,'text_logo_letter_spacing', '');
                                    ?>
                                    <input type="text" name="options[text_logo_letter_spacing]" value="<?php echo $text_logo_letter_spacing; ?>" placeholder="10px"/>

                                    <p class="field-description"><?php _e('Set latter spacing, applicable for text logo. Ex: 10px', 'wp-megamenu'); ?></p>
                                </label>
                            </td>
                        </tr>

                        <tr class="wpmm-field wpmm-field-group">
                            <td>
                                <?php _e('Text Logo Color', 'wp-megamenu'); ?>
                            </td>
                            <td>
                                <input type="text" name="options[text_logo_color]" value="<?php echo wpmm_get_item_settings($menu_item_id, 'text_logo_color'); ?>" class="wpmmColorPicker" data-alpha="true" />
                                <p class="field-description"><?php _e('Set Logo Color, applicable for text logo', 'wp-megamenu'); ?></p>
                            </td>
                        </tr>


                    </table>
                <?php } ?>
            </div>
        </td>
    </tr>

<?php

    $menu_content = ob_get_contents();
    ob_end_clean();
    echo $menu_content;

}
