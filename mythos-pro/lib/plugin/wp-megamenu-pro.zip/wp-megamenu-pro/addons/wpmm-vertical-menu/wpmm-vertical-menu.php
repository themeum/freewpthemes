<?php 

// menu settings
include_once('settings.php');


/*-----------------------------------------------------
 * 				script load
 *----------------------------------------------------*/

function wpmm_vertical_menu_scripts(){
    wp_enqueue_style('wpmm_vertical_menu_css', WPMM_PRO_DIR_URL . 'addons/wpmm-vertical-menu/assets/wpmm-vertical-menu.css', WPMM_PRO_VERSION, true);
    wp_enqueue_script('wpmm_vertical_menu_js', WPMM_PRO_DIR_URL . 'addons/wpmm-vertical-menu/assets/wpmm-vertical-menu.js', array('wpmm_js'), WPMM_PRO_VERSION, true);
}
add_action('wp_enqueue_scripts', 'wpmm_vertical_menu_scripts');


/*-----------------------------------------------------
 * 		pass custom attributes into menu
 *----------------------------------------------------*/
add_filter('wpmm_custom_attributes', function ($args, $theme_id) {
    $wpmm_orientation = !empty(get_wpmm_theme_option('wpmm_orientation_align', $theme_id)) ? get_wpmm_theme_option('wpmm_orientation_align', $theme_id) : 'wpmm_vertical_left';
    $wpmm_container_width = !empty(get_wpmm_theme_option('wpmm_vertical_container_width', $theme_id)) ? get_wpmm_theme_option('wpmm_vertical_container_width', $theme_id) : '1140px';
    $wpmm_menu_width = !empty(get_wpmm_theme_option('wpmm_vertical_menu_width', $theme_id)) ? get_wpmm_theme_option('wpmm_vertical_menu_width', $theme_id) : '220px';
    $wpmm_cont_attr = "data-wpmm_width='{$wpmm_container_width}' data-wpmm_oriantation='{$wpmm_orientation}' data-width='{$wpmm_menu_width}'";
    
    return $args . $wpmm_cont_attr;
}, 10, 2);


/*-----------------------------------------------------
 * 		add custom class into menu wraper
 *----------------------------------------------------*/

add_filter('wpmm_wraper_class', function($args, $theme_id){
    $wpmm_orientation = get_wpmm_theme_option('wpmm_orientation', $theme_id);
    $wpmm_orientation_align = get_wpmm_theme_option('wpmm_orientation_align', $theme_id);
    $vertical_class = $wpmm_orientation === 'wpmm_vertical' ? 'wpmm_vertical_menu wpmm_vertical_menu_active' : 'wpmm_horizontal_menu';
    $vertical_align_class = $wpmm_orientation_align === 'wpmm_vertical_right' ? 'wpmm_right' : 'wpmm_left';
    return $args.$vertical_class.' '.$vertical_align_class.' ';
}, 10, 2);