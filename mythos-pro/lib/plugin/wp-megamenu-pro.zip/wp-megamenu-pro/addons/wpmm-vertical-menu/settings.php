<?php


add_action('wpmm_settings_tab_menu_before', function () {
    $menu_item = '<li><a href="#tabs-115">' . __('Vertical Menu', 'wp-megamenu') . '<sup class="badge">pro</sup></a></li>';
    echo $menu_item;
});

add_action('wpmm_settings_tab_content', function ($theme_id) {

    ob_start();
?>
    <div id="tabs-115">
        <table class="form-table wpmm-option-table wpmm-main-setting-table">
            <tr class="wpmm-fields-header wpmm-field-group wpmm-table-divider">
                <th colspan="2"> <?php _e('Vertical Menu Settings', 'wp-megamenu'); ?> </th>
            </tr>


            <tr class="wpmm-field-group">
                <th><?php _e('Orientation', 'wp-megamenu') ?></th>
                <td>
                    <?php 
                    $wpmm_orientation = get_wpmm_theme_option('wpmm_orientation', $theme_id);
                    $wpmm_orientation_align = get_wpmm_theme_option('wpmm_orientation_align', $theme_id);
                    ?>
                    <select name="wpmm_theme_option[wpmm_orientation]" id="wpmm_orientation">
                        <option 
                            value="wpmm_horizontal" 
                            <?php echo $wpmm_orientation == 'wpmm_horizontal' ? 'selected' : ''; ?> 
                        >
                            <?php _e('Horizontal Menu ', 'wp-megamenu'); ?>
                        </option>
                        <option 
                            value="wpmm_vertical" 
                            <?php echo $wpmm_orientation == 'wpmm_vertical' ? 'selected' : ''; ?>
                        >
                            <?php _e('Vertical Menu ', 'wp-megamenu'); ?>
                        </option>
                    </select>

                    <h5><?php _e(' Vertical menu alignment:', 'wp-megamenu'); ?> </h5>
                    <select name="wpmm_theme_option[wpmm_orientation_align]" id="wpmm_orientation_align">
                        <option 
                            value="wpmm_horizontal_left" 
                            <?php echo $wpmm_orientation_align == 'wpmm_horizontal_left' ? 'selected' : ''; ?>
                        >
                            <?php _e('Left ', 'wp-megamenu'); ?>
                        </option>
                        <option 
                            value="wpmm_vertical_right" 
                            <?php echo $wpmm_orientation_align == 'wpmm_vertical_right' ? 'selected' : ''; ?>
                        >
                            <?php _e('Right ', 'wp-megamenu'); ?>
                        </option>
                    </select>

                </td>
            </tr>

            <tr class="wpmm-field-group">
                <th>
                    <?php _e('Vertical Menu & Container Width', 'wp-megamenu'); ?>
                </th>
                <?php 

                $wpmm_menu_width = get_wpmm_theme_option('wpmm_vertical_menu_width', $theme_id);
                $wpmm_menu_width = empty($wpmm_menu_width) ? '220px' : $wpmm_menu_width;
                $wpmm_container_width = get_wpmm_theme_option('wpmm_vertical_container_width', $theme_id);
                $wpmm_container_width = empty($wpmm_container_width) ? '1140px' : $wpmm_container_width;
                ?>

                <td>
                    <h5><?php _e('Menu Width:', 'wp-megamenu'); ?> </h5>
                    <input type="text" placeholder="230px" name="wpmm_theme_option[wpmm_vertical_menu_width]" value="<?php echo $wpmm_menu_width; ?>"  />
                    <p class="field-description"><?php _e('Vertical Menu Width, default: 230px.', 'wp-megamenu'); ?></p>

                    <h5><?php _e('Menu Container Width:', 'wp-megamenu'); ?></h5>
                    <input type="text" placeholder="1140px" name="wpmm_theme_option[wpmm_vertical_container_width]" value="<?php echo $wpmm_container_width; ?>"  />
                    <p class="field-description"><?php _e('Vertical Menu Container Width, default: 1140px.', 'wp-megamenu'); ?></p>
                </td>
            </tr>

        </table>
    </div>
<?php 

    $menu_content = ob_get_contents();
    ob_end_clean();
    echo $menu_content;
});
