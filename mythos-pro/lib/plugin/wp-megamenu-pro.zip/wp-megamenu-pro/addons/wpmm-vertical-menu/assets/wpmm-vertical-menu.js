(function ($) {
    // Vertical Menu 
    function vertical_menu_active() {
        var current_width = parseInt($(window).width()),
            wpmm_responsive_breakpoint = parseInt(wpmm_object.wpmm_responsive_breakpoint.replace('px', ''));
        if (current_width < wpmm_responsive_breakpoint) {
            $('.wpmm_vertical_menu').removeClass('wpmm_vertical_menu_active');
        } else {
            $('.wpmm_vertical_menu').addClass('wpmm_vertical_menu_active');
            $('.wpmm_vertical_menu [data-wpmm_width]').each(function () {
                var wpmm_item_width = parseInt($(this).attr('data-wpmm_width').replace('px', '').replace('%', '')),
                    wpmm_mm_item = $(this).find('.wpmm_mega_menu > .wp-megamenu-sub-menu'),
                    orientation_align = $(this).attr('data-wpmm_oriantation'),
                    wpmm_menu_width = $(this).attr('data-width'),
                    wpmm_item_width = wpmm_item_width > current_width ? (current_width - 20) : wpmm_item_width,
                    wpmm_item_padding = $(this).closest('.wp-megamenu-wrap').outerWidth() - $(this).closest('.wp-megamenu-wrap').width();

                // styles
                $(this).css('width', wpmm_menu_width - wpmm_item_padding);
                wpmm_mm_item.width((wpmm_item_width - wpmm_item_padding) - $(this).width());
                if (orientation_align === 'wpmm_vertical_right') {
                    wpmm_mm_item.css({
                        left: 'auto',
                        right: $(this).width() + (wpmm_item_padding / 2) + 'px',
                        marginRight: '0'
                    });
                } else {
                    wpmm_mm_item.css({
                        right: 'auto',
                        left: $(this).width() + (wpmm_item_padding / 2) + 'px',
                        marginLeft: '0'
                    });
                }
            });
        }


    }
    vertical_menu_active();

    $(window).on('resize load', vertical_menu_active);
}(jQuery))