<?php

if ( ! class_exists('WPMM_Pro_General')){

    class WPMM_Pro_General{

        public function __construct() {
            add_filter('wpmm_api_request_body', array($this, 'wpmm_api_request_body'), 10);
            add_filter('wpmm_page_data', array($this, 'get_wpmm_page_data'));
        }

        /**
         * @param $arr
         *
         * @return mixed
         */

        public function wpmm_api_request_body($arr){
            $arr['wpmm_pro_request_version'] = WPMM_PRO_VERSION;
            return $arr;
        }



        public function get_wpmm_page_data($page_data){
            $page_data['WPMM_PRO_VERSION'] = WPMM_PRO_VERSION;
            return $page_data;
        }


    }


}