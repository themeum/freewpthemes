<?php

class WPMM_Pro{
    public static $instance = null;

    public $wpmm_updater;
    public $wpmm_pro_general;
    public $wpmm_pro_addons;

    /**
     * WPMM constructor
     */
    public function __construct() {
        $this->register_autoloader();
        add_action( 'init', array($this, 'init'), 0 );
    }

    public function init(){
        $this->init_components();
    }

    /**
     * @return null|WPMM
     *
     * instance of WPMM Class
     */
    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
            do_action( 'wpmm_pro_loaded' );
        }

        return self::$instance;
    }

    /**
     * Auto load class
     */
    private function register_autoloader() {
        require WPMM_PRO_DIR_PATH . 'classes/WPMM_Pro_Autoloader.php';
        \WPMM_Pro\WPMM_Pro_Autoloader::run();
    }

    /**
     * Init all components
     *
     * @since v.1.0.0
     */
    private function init_components(){
        $this->wpmm_updater = new  WPMM_Updater();
        $this->wpmm_pro_general = new  WPMM_Pro_General();
        $this->wpmm_pro_addons = new  WPMM_Pro_Addons();

//          License Restriction removed from v_1.2.4
//        if($this->wpmm_updater->is_valid()){
//            $this->wpmm_pro_general = new  WPMM_Pro_General();
//            $this->wpmm_pro_addons = new  WPMM_Pro_Addons();
//        }
    }

}

if (! function_exists('wpmm_pro_init')){
    function wpmm_pro_init(){
        WPMM_Pro::instance();
    }
}
wpmm_pro_init();