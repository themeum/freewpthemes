<?php

if ( ! class_exists('WPMM_Pro_Addons')){
    class WPMM_Pro_Addons{

        public function __construct() {
            $this->load_pro_addons();
        }

        public function load_pro_addons(){
            $addons_dir = array_filter(glob(WPMM_PRO_DIR_PATH . 'addons/*'), 'is_dir');
            if (count($addons_dir) > 0) {
                foreach ($addons_dir as $key => $value) {
                    $addon_dir_name = str_replace(dirname($value) . '/', '', $value);
                    $file_name = WPMM_PRO_DIR_PATH . 'addons/' . $addon_dir_name . '/' . $addon_dir_name . '.php';
                    if (file_exists($file_name)) {
                        include_once $file_name;
                    }
                }
            }
        }
    }
}
